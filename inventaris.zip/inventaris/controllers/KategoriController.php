<?php

require_once __DIR__ . "/../models/Kategori.php";
require_once __DIR__ . "/../helpers/Response.php";

class KategoriController {

    public function index(){

        $model = new Kategori();
        $data = $model->getAll();

        Response::json([
            "status" => "success",
            "data" => $data
        ]);
    }

    public function create(){

        $nama_kategori = $_POST['nama_kategori'] ?? null;
        $keterangan = $_POST['keterangan'] ?? null;

        if (!$nama_kategori) {
            Response::error("Nama kategori wajib diisi", 400);
            return;
        }

        $model = new Kategori();
        if ($model->create($nama_kategori, $keterangan)) {
            Response::json([
                "status" => "success",
                "message" => "Kategori berhasil ditambahkan"
            ]);
        } else {
            Response::error("Gagal menambahkan kategori", 400);
        }
    }

    public function update(){

        parse_str(file_get_contents("php://input"), $putData);

        $id = $putData['id'] ?? null;
        $nama_kategori = $putData['nama_kategori'] ?? null;
        $keterangan = $putData['keterangan'] ?? null;

        if (!$id || !$nama_kategori) {
            Response::error("ID dan nama kategori wajib diisi", 400);
            return;
        }

        $model = new Kategori();
        if ($model->update($id, $nama_kategori, $keterangan)) {
            Response::json([
                "status" => "success",
                "message" => "Kategori berhasil diupdate"
            ]);
        } else {
            Response::error("Gagal update kategori", 400);
        }
    }

    public function delete(){

        parse_str(file_get_contents("php://input"), $deleteData);

        $id = $deleteData['id'] ?? null;

        if (!$id) {
            Response::error("ID kategori wajib diisi", 400);
            return;
        }

        $model = new Kategori();
        if ($model->delete($id)) {
            Response::json([
                "status" => "success",
                "message" => "Kategori berhasil dihapus"
            ]);
        } else {
            Response::error("Gagal menghapus kategori", 400);
        }
    }

}