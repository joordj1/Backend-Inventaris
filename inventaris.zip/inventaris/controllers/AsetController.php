<?php

require_once __DIR__ . "/../models/Aset.php";
require_once __DIR__ . "/../helpers/Response.php";

class AsetController {

    public function index() {
        $model = new Aset();
        $data = $model->getAll();
        Response::json([
            "status" => "success",
            "data" => $data
        ]);
    }

    public function create() {
        $data = [
            "id_kantor" => $_POST['id_kantor'] ?? null,
            "id_kategori" => $_POST['id_kategori'] ?? null,
            "id_lokasi" => $_POST['id_lokasi'] ?? null,
            "kode_barcode" => $_POST['kode_barcode'] ?? null,
            "nama_aset" => $_POST['nama_aset'] ?? null,
            "merk" => $_POST['merk'] ?? null,
            "tipe" => $_POST['tipe'] ?? null,
            "tahun_perolehan" => $_POST['tahun_perolehan'] ?? null,
            "harga_perolehan" => $_POST['harga_perolehan'] ?? null,
            "kondisi" => $_POST['kondisi'] ?? null,
            "status" => $_POST['status'] ?? null,
            "lokasi" => $_POST['lokasi'] ?? null
        ];

        $model = new Aset();
        if ($model->create($data)) {
            Response::json([
                "status" => "success",
                "message" => "Aset berhasil ditambahkan"
            ]);
        } else {
            Response::json([
                "status" => "error",
                "message" => "Gagal menambahkan aset"
            ], 400);
        }
    }

    public function update($id) {
        $putData = [];
        parse_str(file_get_contents("php://input"), $putData);
        if (!$id) {
            Response::error("ID aset wajib diisi", 400);
            return;
        }
        if (empty($putData)) {
            Response::error("Tidak ada data yang diberikan untuk update", 400);
            return;
        }
        $model = new Aset();
        if ($model->update($id, $putData)) {
            Response::json([
                "status" => "success",
                "message" => "Aset berhasil diupdate"
            ]);
        } else {
            Response::error("Gagal mengupdate aset", 400);
        }
    }

    public function delete($id) {
        if (!$id) {
            Response::error("ID aset wajib diisi", 400);
            return;
        }
        $model = new Aset();
        if ($model->delete($id)) {
            Response::json([
                "status" => "success",
                "message" => "Aset berhasil dihapus"
            ]);
        } else {
            Response::error("Gagal menghapus aset", 400);
        }
    }
}