<?php
require_once "../config/database.php";

$database = new Database();
$conn = $database->connect();

$query = "SELECT status, COUNT(*) as total 
          FROM aset 
          GROUP BY status";

$stmt = $conn->prepare($query);
$stmt->execute();

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($data);