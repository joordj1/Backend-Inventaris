<?php

require_once __DIR__ . "/../models/User.php";
require_once __DIR__ . "/../helpers/Response.php";

class UserController {
    public function index() {
        $model = new User();
        $data = $model->getAll();
        Response::json([
            "status" => "success",
            "data" => $data
        ]);
    }

    public function create() {
        $username = $_POST['username'] ?? null;
        $password = $_POST['password'] ?? null;
        $role = $_POST['role'] ?? null;

        if (!$username || !$password) {
            Response::error("username dan password wajib diisi", 400);
            return;
        }

        $model = new User();
        if ($model->create($username, $password, $role)) {
            Response::json([
                "status" => "success",
                "message" => "User berhasil ditambahkan"
            ]);
        } else {
            Response::error("Gagal menambahkan user", 400);
        }
    }
}