<?php
session_start();
require_once "../models/User.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $userModel = new User();
    $user = $userModel->login($username);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        echo json_encode(["message" => "Login berhasil"]);
    } else {
        echo json_encode(["message" => "Username atau password salah"]);
    }
}