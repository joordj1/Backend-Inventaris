<?php

require_once __DIR__ . "/../models/Peminjaman.php";
require_once __DIR__ . "/../helpers/Response.php";

class PeminjamanController {

    public function index() {
        $model = new Peminjaman();
        $data = $model->getAll();
        Response::json([
            "status" => "success",
            "data" => $data
        ]);
    }

    public function create() {
        $aset_id = $_POST['aset_id'] ?? null;
        $user_id = $_POST['user_id'] ?? null;

        if (!$aset_id || !$user_id) {
            Response::error("aset_id dan user_id wajib diisi", 400);
            return;
        }

        $model = new Peminjaman();
        if ($model->create($aset_id, $user_id)) {
            Response::json([
                "status" => "success",
                "message" => "Aset berhasil dipinjam"
            ]);
        } else {
            Response::error("Gagal memproses peminjaman", 400);
        }
    }

    public function kembali($id) {
        if (!$id) {
            Response::error("id peminjaman tidak boleh kosong", 400);
            return;
        }

        $model = new Peminjaman();
        if ($model->markReturned($id)) {
            Response::json([
                "status" => "success",
                "message" => "Peminjaman berhasil dikembalikan"
            ]);
        } else {
            Response::error("Gagal mengembalikan peminjaman", 400);
        }
    }
}