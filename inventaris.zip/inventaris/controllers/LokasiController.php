<?php

require_once __DIR__ . "/../models/Lokasi.php";
require_once __DIR__ . "/../helpers/Response.php";

class LokasiController {

    public function index() {
        $model = new Lokasi();
        $data = $model->getAll();
        Response::json([
            "status" => "success",
            "data" => $data
        ]);
    }

    public function create() {
        $nama_lokasi = $_POST['nama_lokasi'] ?? null;
        $keterangan = $_POST['keterangan'] ?? null;

        if (!$nama_lokasi) {
            Response::error("Nama lokasi wajib diisi", 400);
            return;
        }

        $model = new Lokasi();
        if ($model->create($_POST['id_kantor'] ?? null, $nama_lokasi, $keterangan)) {
            Response::json([
                "status" => "success",
                "message" => "Lokasi berhasil ditambahkan"
            ]);
        } else {
            Response::error("Gagal menambahkan lokasi", 400);
        }
    }

    public function update() {
        parse_str(file_get_contents("php://input"), $putData);

        $id = $putData['id'] ?? null;
        $nama_lokasi = $putData['nama_lokasi'] ?? null;
        $keterangan = $putData['keterangan'] ?? null;

        if (!$id || !$nama_lokasi) {
            Response::error("ID dan nama lokasi wajib diisi", 400);
            return;
        }

        $model = new Lokasi();
        if ($model->update($id, $nama_lokasi, $keterangan)) {
            Response::json([
                "status" => "success",
                "message" => "Lokasi berhasil diupdate"
            ]);
        } else {
            Response::error("Gagal update lokasi", 400);
        }
    }

    public function delete() {
        parse_str(file_get_contents("php://input"), $deleteData);

        $id = $deleteData['id'] ?? null;

        if (!$id) {
            Response::error("ID lokasi wajib diisi", 400);
            return;
        }

        $model = new Lokasi();
        if ($model->delete($id)) {
            Response::json([
                "status" => "success",
                "message" => "Lokasi berhasil dihapus"
            ]);
        } else {
            Response::error("Gagal menghapus lokasi", 400);
        }
    }
}