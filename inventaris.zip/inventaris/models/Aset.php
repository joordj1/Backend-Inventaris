<?php
require_once __DIR__ . "/../config/database.php";

class Aset {

    private $conn;
    private $table = "aset";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    // ambil semua aset + relasi
    public function getAll(){

        $query = "SELECT 
                    a.id_aset,
                    a.kode_barcode,
                    a.nama_aset,
                    a.merk,
                    a.tipe,
                    a.tahun_perolehan,
                    a.harga_perolehan,
                    a.kondisi,
                    a.status,
                    k.nama_kategori,
                    l.nama_lokasi,
                    ko.nama_kantor
                  FROM aset a
                  JOIN kategori_aset k ON a.id_kategori = k.id_kategori
                  JOIN lokasi l ON a.id_lokasi = l.id_lokasi
                  JOIN kantor ko ON a.id_kantor = ko.id_kantor
                  ORDER BY a.id_aset DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // tambah aset
    public function create($data){

        $query = "INSERT INTO aset
                  (id_kantor,id_kategori,id_lokasi,kode_barcode,nama_aset,merk,tipe,
                   tahun_perolehan,harga_perolehan,kondisi,status,lokasi,created_at)
                  VALUES
                  (:id_kantor,:id_kategori,:id_lokasi,:kode_barcode,:nama_aset,:merk,:tipe,
                   :tahun_perolehan,:harga_perolehan,:kondisi,:status,:lokasi,NOW())";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute($data);
    }

    public function update($id, $data) {
        // build set clause dynamically
        $fields = [];
        foreach ($data as $column => $value) {
            $fields[] = "{$column} = :{$column}";
        }
        $setClause = implode(', ', $fields);

        $query = "UPDATE aset SET {$setClause} WHERE id_aset = :id";
        $stmt = $this->conn->prepare($query);
        foreach ($data as $column => $value) {
            $stmt->bindValue(":{$column}", $value);
        }
        $stmt->bindValue(':id', $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM aset WHERE id_aset = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}