<?php

require_once __DIR__ . "/../config/database.php";

class Kategori {

    private $conn;
    private $table = "kategori_aset";

    public function __construct(){
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function getAll(){

        $query = "SELECT * FROM " . $this->table . " ORDER BY id_kategori DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id){

        $query = "SELECT * FROM " . $this->table . " WHERE id_kategori = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($nama_kategori, $keterangan = null){

        $query = "INSERT INTO " . $this->table . "
                  (nama_kategori, keterangan, created_at)
                  VALUES (:nama_kategori, :keterangan, NOW())";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":nama_kategori", $nama_kategori);
        $stmt->bindParam(":keterangan", $keterangan);

        return $stmt->execute();
    }

    public function update($id, $nama_kategori, $keterangan = null){

        $query = "UPDATE " . $this->table . "
                  SET nama_kategori = :nama_kategori,
                      keterangan = :keterangan
                  WHERE id_kategori = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":nama_kategori", $nama_kategori);
        $stmt->bindParam(":keterangan", $keterangan);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }

    public function delete($id){

        $query = "DELETE FROM " . $this->table . " WHERE id_kategori = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }

}