<?php
require_once "../config/database.php";

class Peminjaman {
    private $conn;
    private $table = "peminjaman";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function getAll() {
        $query = "SELECT p.id_peminjaman, p.id_aset, a.nama_aset, p.id_user, u.username, p.tanggal_pinjam, p.tanggal_kembali, p.status
                  FROM peminjaman p
                  LEFT JOIN aset a ON p.id_aset = a.id_aset
                  LEFT JOIN users u ON p.id_user = u.id_user
                  ORDER BY p.id_peminjaman DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($aset_id, $user_id) {
        $this->conn->beginTransaction();

        try {
            $query = "INSERT INTO peminjaman 
                      (id_aset, id_user, tanggal_pinjam, status)
                      VALUES (:aset, :user, NOW(), 'dipinjam')";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":aset", $aset_id);
            $stmt->bindParam(":user", $user_id);
            $stmt->execute();

            $update = "UPDATE aset SET status='dipinjam' WHERE id_aset=:id";
            $stmt2 = $this->conn->prepare($update);
            $stmt2->bindParam(":id", $aset_id);
            $stmt2->execute();

            $this->conn->commit();
            return true;

        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function markReturned($id) {
        $query = "UPDATE peminjaman p
                  JOIN aset a ON p.id_aset = a.id_aset
                  SET p.status='kembali', p.tanggal_kembali=NOW(), a.status='tersedia'
                  WHERE p.id_peminjaman = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}