<?php
require_once __DIR__ . "/../config/database.php";

class Lokasi {

    private $conn;
    private $table = "lokasi";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    // Ambil semua lokasi
    public function getAll() {

        $query = "SELECT * FROM " . $this->table . " ORDER BY id_lokasi DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ambil satu lokasi
    public function getById($id) {

        $query = "SELECT * FROM " . $this->table . " WHERE id_lokasi = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tambah lokasi
    public function create($id_kantor, $nama_lokasi, $keterangan) {

        $query = "INSERT INTO " . $this->table . "
                  (id_kantor, nama_lokasi, keterangan, created_at)
                  VALUES (:id_kantor, :nama_lokasi, :keterangan, NOW())";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":id_kantor", $id_kantor);
        $stmt->bindParam(":nama_lokasi", $nama_lokasi);
        $stmt->bindParam(":keterangan", $keterangan);

        return $stmt->execute();
    }

    // Update lokasi
    public function update($id, $nama_lokasi, $keterangan) {

        $query = "UPDATE " . $this->table . "
                  SET nama_lokasi = :nama_lokasi,
                      keterangan = :keterangan
                  WHERE id_lokasi = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":nama_lokasi", $nama_lokasi);
        $stmt->bindParam(":keterangan", $keterangan);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }

    // Hapus lokasi
    public function delete($id) {

        $query = "DELETE FROM " . $this->table . " WHERE id_lokasi = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }
}