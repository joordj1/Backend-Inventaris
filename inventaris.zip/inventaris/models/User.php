<?php
require_once "../config/database.php";

class User {
    private $conn;
    private $table = "users";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function login($username) {
        $query = "SELECT * FROM " . $this->table . " WHERE username = :username LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAll() {
        // use actual column names and alias id_user to id for consistency
        $query = "SELECT id_user AS id, username, role, nama, status, id_kantor, created_at FROM " . $this->table . " ORDER BY id_user DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($username, $password, $role = null, $nama = null, $id_kantor = null) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO " . $this->table . " (username, password, role, nama, id_kantor, created_at) VALUES (:username, :password, :role, :nama, :id_kantor, NOW())";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hashed);
        $stmt->bindParam(":role", $role);
        $stmt->bindParam(":nama", $nama);
        $stmt->bindParam(":id_kantor", $id_kantor);
        return $stmt->execute();
    }
}