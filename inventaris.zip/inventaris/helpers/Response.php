<?php

class Response {
    public static function json($data, $statusCode = 200) {
        header("Content-Type: application/json");
        http_response_code($statusCode);
        echo json_encode($data);
        exit();
    }

    public static function error($message, $statusCode = 400) {
        self::json([
            "status" => "error",
            "message" => $message
        ], $statusCode);
    }

    public static function success($data, $message = "Success") {
        self::json([
            "status" => "success",
            "message" => $message,
            "data" => $data
        ], 200);
    }
}