<?php

require_once "../controllers/AsetController.php";
require_once "../controllers/LokasiController.php";
require_once "../controllers/KategoriController.php";
require_once "../controllers/AuthController.php";
require_once "../controllers/UserController.php";
require_once "../controllers/PeminjamanController.php";

// Get URL from query parameter (set by .htaccess)
$url = isset($_GET['url']) ? trim($_GET['url'], '/') : '';
$method = $_SERVER['REQUEST_METHOD'];

// Parse URL
$routes = explode('/', $url);

// Routing logic
if (count($routes) >= 2 && $routes[0] === 'api') {
    $resource = $routes[1];
    
    if ($resource === 'user') {
        $controller = new UserController();
        if ($method === 'GET') {
            $controller->index();
        } elseif ($method === 'POST') {
            $controller->create();
        }
    }
    elseif ($resource === 'aset') {
        $controller = new AsetController();
        if ($method === 'GET') {
            $controller->index();
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT' || $method === 'DELETE') {
            $id = $routes[2] ?? null;
            if ($method === 'PUT') {
                $controller->update($id);
            } elseif ($method === 'DELETE') {
                $controller->delete($id);
            }
        }
    } 
    elseif ($resource === 'lokasi') {
        $controller = new LokasiController();
        if ($method === 'GET') {
            $controller->index();
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $controller->update();
        } elseif ($method === 'DELETE') {
            $controller->delete();
        }
    } 
    elseif ($resource === 'kategori') {
        $controller = new KategoriController();
        if ($method === 'GET') {
            $controller->index();
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $controller->update();
        } elseif ($method === 'DELETE') {
            $controller->delete();
        }
    } 
    elseif ($resource === 'peminjaman') {
        $controller = new PeminjamanController();
        if ($method === 'GET') {
            $controller->index();
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $id = $routes[2] ?? null;
            $action = $routes[3] ?? null;
            if ($action === 'kembali') {
                $controller->kembali($id);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Route not found']);
            }
        }
    }
    else {
        http_response_code(404);
        echo json_encode(['error' => 'Resource not found']);
    }
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Not Found']);
}