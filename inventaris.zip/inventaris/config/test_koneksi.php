<?php
require_once "database.php";

$database = new Database();
$conn = $database->connect();

if ($conn) {
    echo "Koneksi berhasil";
} else {
    echo "Koneksi gagal";
}