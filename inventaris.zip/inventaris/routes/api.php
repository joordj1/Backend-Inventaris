<?php

require_once __DIR__ . "/../controllers/AsetController.php";
require_once __DIR__ . "/../controllers/LokasiController.php";
require_once __DIR__ . "/../controllers/KategoriController.php";

$uri = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

if ($uri == "/inventaris/api/aset" && $method == "GET") {

    $controller = new AsetController();
    $controller->index();
}

if ($uri == "/inventaris/api/lokasi" && $method == "GET") {

    $controller = new LokasiController();
    $controller->index();
}

if ($uri == "/inventaris/api/kategori" && $method == "GET") {

    $controller = new KategoriController();
    $controller->index();
}